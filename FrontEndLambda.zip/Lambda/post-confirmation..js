const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    console.log("Post-Confirmation Event:", JSON.stringify(event, null, 2));

    const tableName = process.env.USERS_TABLE;
    const { sub, email, name } = event.request.userAttributes;

    const params = {
        TableName: tableName,
        Item: {
            userId: sub,
            email: email,
            name: name || '',
            createdAt: new Date().toISOString()
        }
    };

    try {
        await docClient.send(new PutCommand(params));
        console.log(`Usuário ${sub} salvo com sucesso no DynamoDB.`);
    } catch (error) {
        console.error("Erro ao salvar no DynamoDB:", error);
        throw error;
    }

    return event;
};