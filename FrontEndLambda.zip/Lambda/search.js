exports.handler = async (event) => {
    console.log("Search Event:", JSON.stringify(event, null, 2));
    const openSearchEndpoint = process.env.OPENSEARCH_ENDPOINT;

    // Obtém o termo de busca dos query parâmetros (?q=termo)
    const query = event.queryStringParameters?.q || "";

    return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            message: "Busca realizada com sucesso",
            endpoint: openSearchEndpoint,
            query: query,
            results: []
        })
    };
};