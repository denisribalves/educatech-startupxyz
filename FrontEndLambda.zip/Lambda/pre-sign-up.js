exports.handler = async (event) => {
    console.log("Pre-SignUp Event:", JSON.stringify(event, null, 2));

    // Exemplo: Auto-confirma o email do usuário se necessário
    event.response.autoConfirmUser = true;
    event.response.autoVerifyEmail = true;

    return event;
};