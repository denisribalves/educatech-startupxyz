exports.handler = async (event) => {
    console.log("Indexer Event (DynamoDB Stream):", JSON.stringify(event, null, 2));
    const openSearchEndpoint = process.env.OPENSEARCH_ENDPOINT;

    for (const record of event.Records) {
        console.log(`Processando evento ${record.eventName} da tabela de Cursos.`);
        // Lógica de envio ao OpenSearch conforme eventos INSERT / MODIFY / REMOVE
    }

    return { statusCode: 200, body: "Indexação concluída." };
};